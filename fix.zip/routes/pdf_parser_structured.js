const express = require('express');
const router = express.Router();

function parseStructuredText(textItems, type, subject, paperNo) {
  if (!textItems || !Array.isArray(textItems) || textItems.length === 0) {
    return [];
  }

  // Step 1: Sort by page, then y (descending), then x (ascending)
  const sorted = [...textItems].sort((a, b) => {
    if (a.page !== b.page) return a.page - b.page;
    if (Math.abs(a.y - b.y) > 4) return b.y - a.y;
    return a.x - b.x;
  });

  // Step 2: Group items into lines by y-proximity
  const lines = [];
  let currentLine = [];
  let currentY = null;
  let currentPage = null;

  for (const item of sorted) {
    if (currentY === null || currentPage === null || item.page !== currentPage || Math.abs(item.y - currentY) > 4) {
      if (currentLine.length > 0) {
        currentLine.sort((a, b) => a.x - b.x);
        const fullText = currentLine.map(i => i.text).join(' ').trim();
        const avgHeight = currentLine.reduce((sum, i) => sum + (i.height || 12), 0) / currentLine.length;
        lines.push({
          text: fullText,
          y: currentY,
          page: currentPage,
          xStart: currentLine[0].x,
          xEnd: currentLine[currentLine.length - 1].x + (currentLine[currentLine.length - 1].width || 0),
          fontHeight: avgHeight,
          items: currentLine
        });
      }
      currentLine = [item];
      currentY = item.y;
      currentPage = item.page;
    } else {
      currentLine.push(item);
    }
  }
  if (currentLine.length > 0) {
    currentLine.sort((a, b) => a.x - b.x);
    const fullText = currentLine.map(i => i.text).join(' ').trim();
    const avgHeight = currentLine.reduce((sum, i) => sum + (i.height || 12), 0) / currentLine.length;
    lines.push({
      text: fullText,
      y: currentY,
      page: currentPage,
      xStart: currentLine[0].x,
      xEnd: currentLine[currentLine.length - 1].x + (currentLine[currentLine.length - 1].width || 0),
      fontHeight: avgHeight,
      items: currentLine
    });
  }

  // Step 3: Detect sections and question numbers
  let maxFontHeight = 0;
  for (const line of lines) {
    if (line.fontHeight > maxFontHeight) maxFontHeight = line.fontHeight;
  }
  const headerThreshold = maxFontHeight * 0.82;

  const sectionPattern = /^SECTION\s+([A-C])/i;
  const qnumPattern = /^(\d+\.\d+\.\d+|\d+\.\d+)(?:\s+|[A-Z]|$)/;
  const qnumOnlyPattern = /^(\d+\.\d+\.\d+|\d+\.\d+)$/;
  const marksBatchPattern = /\((\d+)\s*x\s*(\d+)\)\s*\((\d+)\)/;
  const marksSinglePattern = /\((\d+)\)(?!\s*\()/;

  const structure = [];
  let currentSection = null;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const text = line.text.trim();
    if (!text) continue;

    const sectionMatch = text.match(sectionPattern);
    if (sectionMatch && line.fontHeight >= headerThreshold) {
      currentSection = 'Section ' + sectionMatch[1];
      structure.push({ type: 'section_header', section: currentSection, text, line });
      continue;
    }

    const qnumMatch = text.match(qnumPattern);
    if (qnumMatch) {
      const qnum = qnumMatch[1];
      const remainingText = text.substring(qnumMatch[0].length).trim();

      let marks = 1;
      let marksFound = false;

      const batchMarks = remainingText.match(marksBatchPattern);
      if (batchMarks) {
        marks = qnum.split('.').length === 2 ? parseInt(batchMarks[3]) : parseInt(batchMarks[2]);
        marksFound = true;
      } else {
        const singleMarks = remainingText.match(marksSinglePattern);
        if (singleMarks) {
          marks = parseInt(singleMarks[1]);
          marksFound = true;
        }
      }

      // Check next 5 lines for marks (increased from 2 to 5)
      if (!marksFound) {
        for (let j = i + 1; j < Math.min(i + 5, lines.length); j++) {
          const nextLine = lines[j];
          const nextText = nextLine.text.trim();
          if (nextText.match(qnumPattern) || nextText.match(qnumOnlyPattern)) break;
          const bm2 = nextText.match(marksBatchPattern);
          if (bm2) {
            marks = qnum.split('.').length === 2 ? parseInt(bm2[3]) : parseInt(bm2[2]);
            marksFound = true;
            break;
          }
          const sm2 = nextText.match(marksSinglePattern);
          if (sm2) {
            marks = parseInt(sm2[1]);
            marksFound = true;
            break;
          }
        }
      }

      structure.push({
        type: 'question',
        question_number: qnum,
        text: remainingText,
        marks,
        section: currentSection || 'Section A',
        line,
        page: line.page
      });
      continue;
    }

    // Detect standalone marks lines - store them for later matching
    const batchMarksStandalone = text.match(marksBatchPattern);
    if (batchMarksStandalone) {
      structure.push({ 
        type: 'batch_marks', 
        numQuestions: parseInt(batchMarksStandalone[1]),
        marksPerQuestion: parseInt(batchMarksStandalone[2]),
        totalMarks: parseInt(batchMarksStandalone[3]),
        text, 
        line 
      });
      continue;
    }

    if (text.match(/^\(\d+\)$/)) {
      structure.push({ type: 'marks_line', text, line });
      continue;
    }

    if (text.match(/\[(\d+)\]/) && text.includes('TOTAL')) {
      structure.push({ type: 'section_total', total: parseInt(text.match(/\[(\d+)\]/)[1]), text, line });
      continue;
    }

    structure.push({ type: 'text', text, line });
  }

  // Step 4: Build questions with full text
  const questions = [];
  let currentQuestion = null;
  let questionBuffer = [];

  for (let i = 0; i < structure.length; i++) {
    const element = structure[i];
    if (element.type === 'section_header') {
      if (currentQuestion) {
        currentQuestion.question_text = questionBuffer.join(' ').trim();
        questions.push(currentQuestion);
        currentQuestion = null;
        questionBuffer = [];
      }
      continue;
    }
    if (element.type === 'question') {
      if (currentQuestion) {
        currentQuestion.question_text = questionBuffer.join(' ').trim();
        questions.push(currentQuestion);
        questionBuffer = [];
      }
      currentQuestion = {
        question_number: element.question_number,
        marks: element.marks,
        section: element.section,
        type: determineType(element.question_number, element.section),
        question_text: element.text,
        page: element.page,
        line: element.line,
        raw_text: [element.text]
      };
      questionBuffer = [element.text];
      continue;
    }
    if (element.type === 'text' && currentQuestion) {
      const lastElement = structure[i - 1];
      if (lastElement && lastElement.line) {
        const yDiff = Math.abs(element.line.y - lastElement.line.y);
        if (yDiff < 100 || element.line.page === lastElement.line.page) {
          questionBuffer.push(element.text);
          currentQuestion.raw_text.push(element.text);
        }
      }
    }
  }
  if (currentQuestion) {
    currentQuestion.question_text = questionBuffer.join(' ').trim();
    questions.push(currentQuestion);
  }

  // Step 5: Match standalone batch marks to parents
  const batchMarksLines = structure.filter(s => s.type === 'batch_marks');

  for (const batchMark of batchMarksLines) {
    const matchingParents = questions.filter(q => {
      const parts = q.question_number.split('.');
      if (parts.length !== 2) return false;
      const children = questions.filter(c => {
        const cp = c.question_number.split('.');
        return cp.length === 3 && cp[0] === parts[0] && cp[1] === parts[1];
      });
      return children.length === batchMark.numQuestions;
    });

    if (matchingParents.length === 1) {
      const parent = matchingParents[0];
      parent.marks = batchMark.totalMarks;
      const children = questions.filter(c => {
        const cp = c.question_number.split('.');
        const pp = parent.question_number.split('.');
        return cp.length === 3 && cp[0] === pp[0] && cp[1] === pp[1];
      });
      for (const child of children) {
        child.marks = batchMark.marksPerQuestion;
      }
    }
  }

  // Step 6: Match standalone single marks lines to nearby questions
  const marksLines = structure.filter(s => s.type === 'marks_line');
  for (const marksLine of marksLines) {
    if (!marksLine.line) continue;
    const marksValue = parseInt(marksLine.text.match(/\((\d+)\)/)[1]);
    const nearbyQuestions = questions.filter(q => q.marks === 1 && q.line);
    if (nearbyQuestions.length > 0) {
      let closest = nearbyQuestions[0];
      let minDist = Math.abs(marksLine.line.y - (closest.page || 1) * 1000 - closest.line.y);
      for (const q of nearbyQuestions) {
        if (!q.line) continue;
        const dist = Math.abs(marksLine.line.y - (q.page || 1) * 1000 - q.line.y);
        if (dist < minDist) {
          minDist = dist;
          closest = q;
        }
      }
      closest.marks = marksValue;
    }
  }

  // Step 7: Build final items based on section
  const finalItems = [];
  let seq = 1;

  for (const q of questions) {
    const parts = q.question_number.split('.');
    const section = q.section;

    if (section === 'Section A') {
      if (parts.length === 3) {
        finalItems.push({
          question_number: q.question_number,
          question_text: cleanText(q.question_text),
          marks: q.marks,
          section: q.section,
          type: determineType(q.question_number, q.section),
          sequence: seq++,
          images: [],
          sub_parts: [],
          child_sub_parts: []
        });
      }
    } else {
      if (parts.length === 2) {
        const children = questions.filter(c => {
          const childParts = c.question_number.split('.');
          return childParts.length === 3 && 
                 childParts[0] === parts[0] && 
                 childParts[1] === parts[1];
        });

        const childSubParts = children.map(c => ({
          number: c.question_number,
          text: c.question_text,
          marks: c.marks
        }));

        const parentMarks = children.reduce((sum, c) => sum + c.marks, 0);

        finalItems.push({
          question_number: q.question_number,
          question_text: cleanText(q.question_text),
          marks: parentMarks || q.marks,
          section: q.section,
          type: determineType(q.question_number, q.section),
          sequence: seq++,
          images: [],
          sub_parts: [],
          child_sub_parts: childSubParts
        });
      }
    }
  }

  return finalItems;
}

function determineType(questionNumber, section) {
  const parts = questionNumber.split('.');

  if (section === 'Section A') {
    if (parts.length === 3) {
      if (parts[1] === '1') return 'MCQ';
      if (parts[1] === '2') return 'Short';
      if (parts[1] === '3') return 'Matching';
      if (parts[1] === '4' || parts[1] === '5') return 'Diagram';
      return 'Short';
    }
    if (parts.length === 2) {
      if (parts[1] === '1') return 'MCQ';
      if (parts[1] === '2') return 'Short';
      if (parts[1] === '3') return 'Matching';
      if (parts[1] === '4' || parts[1] === '5') return 'Diagram';
      return 'Short';
    }
  }

  if (section === 'Section B' || section === 'Section C') {
    if (parts.length === 2) return 'Extended';
    if (parts.length === 3) return 'Sub-part';
  }

  return 'Extended';
}

function cleanText(text) {
  if (!text) return '';
  return text
    .replace(/\s+/g, ' ')
    .replace(/\(\d+\s*x\s*\d+\)\s*\(\d+\)/g, '')
    .replace(/\(\d+\)\s*$/g, '')
    .replace(/\[\d+\]/g, '')
    .replace(/Copyright reserved/gi, '')
    .replace(/Please turn over/gi, '')
    .replace(/NSC Confidential/gi, '')
    .replace(/DBE\/November\s*\d{4}/gi, '')
    .replace(/Life Sciences\/P1/gi, '')
    .replace(/TOTAL SECTION [A-C]:/gi, '')
    .replace(/GRAND TOTAL:/gi, '')
    .trim();
}

router.post('/parse-structured', async (req, res) => {
  try {
    const { textItems, type, subject, paper_no } = req.body;
    if (!textItems || !Array.isArray(textItems) || textItems.length === 0) {
      return res.status(400).json({ success: false, error: 'No text items provided' });
    }
    const items = parseStructuredText(textItems, type, subject, paper_no);
    const totalMarks = items.reduce((sum, i) => sum + i.marks, 0);
    const sectionCounts = {};
    for (const item of items) {
      sectionCounts[item.section] = (sectionCounts[item.section] || 0) + 1;
    }
    res.json({
      success: true,
      extraction_method: 'position-based',
      total_pages: Math.max(...textItems.map(i => i.page || 1)),
      total_items: items.length,
      total_marks: totalMarks,
      section_counts: sectionCounts,
      items: items,
      validation: {
        expected_items: 38,
        expected_marks: 150,
        item_variance: items.length - 38,
        marks_variance: totalMarks - 150
      }
    });
  } catch (e) {
    console.error('Parse error:', e);
    res.status(500).json({ success: false, error: e.message });
  }
});

module.exports = router;
